# -*- coding: utf-8 -*-

def classFactory(iface):
    from .layer2shp import SimpleSaveTemporarylayer
    return SimpleSaveTemporarylayer(iface)
